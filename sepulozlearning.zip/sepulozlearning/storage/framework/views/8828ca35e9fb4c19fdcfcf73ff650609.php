
<?php $__currentLoopData = $bots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<!--
<?php echo e($bot->name); ?> | <?php echo e($bot->firstname); ?> | <?php echo e($bot->lastname); ?> | <?php echo e($bot->age); ?>  <br/>
<form action="/bots/<?php echo e($bot->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input placeholder="please insert your full name" name="name" value="<?php echo e($bot->name); ?>"> <br/>
    <button type="submit">Kemaskini</button>
    
</form>

<form action="/bots/<?php echo e($bot->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit">Padam</button>
</form>

-->

<form action="/" method=POST>
    <?php echo csrf_field(); ?>
    <input placeholder="please insert your full name" name="name"> <br/>
    <input placeholder="please insert your firstname" firstname="firstname"> <br/>
    <input placeholder="please insert your lastname" lastname ="lastname"><br/>
    <input placeholder="please insert your age " age ="age"><br/>
    <button type="submit">Hantar</button>
</form>


<label for="team">please choose a team to support:</label>

<select name="team" id="team">
  <option value="team secret">team secret</option>
  <option value="homebois">homebois</option>
  <option value="idonotsleep">idonotsleep</option>
  <option value="geekfam">geekfam</option>
  <option value="Evos legend">Evos legend</option>
</select>
<br><br>
  <input type="submit" value="submit">
</form>



<?php /**PATH C:\laragon\www\sepulozlearning\resources\views/main.blade.php ENDPATH**/ ?>