<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MybotController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/



Route::get('/', [MyBotController::class, 'tengok_borang']);
Route::post('/', [MyBotController::class, 'hantar_borang']);
Route::put('/bots/{bot_id}', [MyBotController::class, 'kemaskini_bot']);
Route::delete('/bots/{bot_id}', [MyBotController::class, 'padam_bot']);


