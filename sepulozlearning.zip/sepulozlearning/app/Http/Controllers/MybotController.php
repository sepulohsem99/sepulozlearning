<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

use App\Models\Mybot;

class MybotController extends Controller
{
    public function tengok_borang() {
        $response = Http::get('https://api.openai.com/v1/completions');

        $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.apilayer.com/exchangerates_data/latest?symbols=USD&base=MYR",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: text/plain",
    "apikey: Qb6sQdLG5vTM6uDx0KkMRdx5LTbhfDFC"
  ),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET"
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;



        $bots = Mybot::all();
        return view('main', compact('bots'));
    }

    public function hantar_borang(Request $request) {
        $mybot = New Mybot;
        $mybot->name = $request->name;
        $mybot->firstname = $request->firstname;
        $mybot->lastname = $request->lastname;
        $mybot->age = $request->age;
        $mybot->save();

        return back();
    }

    public function kemaskini_bot(Request $request) {
        $id = $request->route('bot_id');
        $mybot = MyBot::find($id);
        $mybot->name = $request->name;
        $mybot->save();

        return back();
    }

    public function padam_bot(Request $request) {
        $id = $request->route('bot_id');
        $mybot = MyBot::find($id);
        $mybot->delete();

        return back();
    }
}